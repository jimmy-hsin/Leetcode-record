#include <iostream>
using namespace std;

int main()
{
    int S,c0,cu,I0,n;
    cin>>S>>c0>>cu>>I0;
    cin>>n;
    int x[n+1]={0};
    x[0]=n;
    for(int i=1;i<=n;i++)
        cin>>x[i];

}